defaultScope(1);
intRange(-8, 7);
stringLength(16);

c0_A = Abstract("c0_A");
c0_B = Abstract("c0_B").extending(c0_A).withGroupCard(1);
c0_C = Abstract("c0_C").extending(c0_B).withGroupCard(1);
c0_D = Abstract("c0_D").extending(c0_C).withGroupCard(1, 1);
c0_a = c0_A.addChild("c0_a").withCard(1, 1);
c0_b = c0_B.addChild("c0_b").withCard(0, 1);
c0_c = c0_C.addChild("c0_c").withCard(0, 1);
c0_d = c0_D.addChild("c0_d").withCard(0, 1);
c0_E = Clafer("c0_E").withCard(1, 1).withGroupCard(1, 1).extending(c0_D);
c0_e = c0_E.addChild("c0_e").withCard(0, 1);
assert(and(and(and(and(one(join(global(c0_E), c0_a)), none(join(global(c0_E), c0_b))), none(join(global(c0_E), c0_c))), none(join(global(c0_E), c0_d))), none(join(global(c0_E), c0_e))));
