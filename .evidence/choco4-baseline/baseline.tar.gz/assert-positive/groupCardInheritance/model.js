defaultScope(1);
intRange(-8, 7);
stringLength(16);

c0_Port = Abstract("c0_Port").withGroupCard(1);
c0_RelayPort = Abstract("c0_RelayPort").extending(c0_Port).withGroupCard(1, 1);
c0_input = c0_Port.addChild("c0_input").withCard(0, 1);
c0_output = c0_Port.addChild("c0_output").withCard(0, 1);
c0_relay = c0_RelayPort.addChild("c0_relay").withCard(0, 1);
c0_req = Clafer("c0_req").withCard(1, 1).withGroupCard(1, 1).extending(c0_RelayPort);
c0_flow = c0_req.addChild("c0_flow").withCard(0, 1);
assert(none(join(global(c0_req), c0_input)));
assert(none(join(global(c0_req), c0_output)));
assert(none(join(global(c0_req), c0_relay)));
assert(one(join(global(c0_req), c0_flow)));
c0_req.addConstraint(some(join($this(), c0_flow)));
