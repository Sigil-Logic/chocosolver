defaultScope(1);
intRange(-8, 7);
stringLength(16);

c0_A = Clafer("c0_A").withCard(1, 1);
c0_i = c0_A.addChild("c0_i").withCard(1, 1);
c0_i.refTo(Int);
c0_A.addConstraint(equal(joinRef(join($this(), c0_i)), constant(1)));
c0_A.addConstraint(equal(joinRef(join($this(), c0_i)), constant(1)));
c0_i.addConstraint(equal(joinRef($this()), constant(1)));
