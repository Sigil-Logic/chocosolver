scope({c0_e:0});
defaultScope(1);
intRange(-8, 7);
stringLength(16);

c0_a = Clafer("c0_a").withCard(1, 1);
c0_b = c0_a.addChild("c0_b").withCard(0, 1);
c0_c = c0_a.addChild("c0_c").withCard(0, 1);
c0_d = Clafer("c0_d").withCard(1, 1);
c0_e = Clafer("c0_e").withCard(0, 0);
c0_f = Clafer("c0_f").withCard(1, 1);
