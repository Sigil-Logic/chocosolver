defaultScope(1);
intRange(-8, 7);
stringLength(16);

c0_A = Clafer("c0_A").withCard(1, 1);
c0_B = c0_A.addChild("c0_B").withCard(1, 1);
c0_C = c0_A.addChild("c0_C").withCard(0, 1);
c0_D = Clafer("c0_D").withCard(1, 1);
c0_D.refTo(c0_A);
