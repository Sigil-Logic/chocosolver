defaultScope(1);
intRange(-8, 7);
stringLength(16);

c0_rate = Clafer("c0_rate").withCard(1, 1);
c0_interest = Clafer("c0_interest").withCard(1, 1);
c0_rate.refTo(real);
c0_interest.refTo(real);
Constraint(equal(joinRef(global(c0_rate)), constant(1.99)));
Constraint(implies(some(global(c0_interest)), equal(joinRef(global(c0_interest)), mul(constant(100), joinRef(global(c0_rate))))));
